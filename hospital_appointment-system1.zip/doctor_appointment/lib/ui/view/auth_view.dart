
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:simple_animations/simple_animations/controlled_animation.dart';
import 'package:simple_animations/simple_animations/multi_track_tween.dart';

import '../../viewmodels/auth_viewmodel.dart';
import 'base_view.dart';


class HomePage extends StatefulWidget {
  final String title;
  final String subtitle;
  const HomePage(this.title, this.subtitle, {Key key}) : super(key: key);
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return BaseView<AuthViewModel>(
        onModelReady: (model) => model.onModelReady(widget.title),
        onModelDestroy: (model) => model.onModelDestroy(),
        builder: (context, model, child) => GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child:Scaffold(
            backgroundColor: Colors.white,
            body: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    height: 400,
                    child: Stack(
                      children: <Widget>[
                        Positioned(
                          top: -40,
                          height: 400,
                          width: width,
                          child: FadeAnimation(1, Container(
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage('assets/images/background.png'),
                                    fit: BoxFit.fill
                                )
                            ),
                          )),
                        ),
                        Positioned(
                          height: 400,
                          width: width+20,
                          child: FadeAnimation(1.3, Container(
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage('assets/images/background-2.png'),
                                    fit: BoxFit.fill
                                )
                            ),
                          )),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 40),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        FadeAnimation(1.5, Text(widget.title, style: TextStyle(color: Color.fromRGBO(49, 39, 79, 1), fontWeight: FontWeight.bold, fontSize: 30),)),
                        SizedBox(height: 30,),
                        FadeAnimation(1.7, Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Color.fromRGBO(196, 135, 198, .3),
                                  blurRadius: 20,
                                  offset: Offset(0, 10),
                                )
                              ]
                          ),
                          child: Form(
                            key: model.formKey,
                            child: Column(
                              children: <Widget>[
                                Container(
                                  padding: EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      border: Border(bottom: BorderSide(
                                          color: Colors.grey[200]
                                      ))
                                  ),
                                  child: TextField(
                                    controller: model.emailController,
                                    decoration: InputDecoration(

                                        border: InputBorder.none,
                                        hintText: "Username",
                                        hintStyle: TextStyle(color: Colors.grey)
                                    ),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.all(10),
                                  child: TextField(
                                    controller: model.passwordController,
                                    decoration: InputDecoration(
                                        border: InputBorder.none,
                                        hintText: "Password",
                                        hintStyle: TextStyle(color: Colors.grey)
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                        )),

                        // FadeAnimation(1.7, Center(child: Text("Forgot Password?", style: TextStyle(color: Color.fromRGBO(196, 135, 198, 1)),))),
                        SizedBox(height: 30,),
                        FadeAnimation(1.9, InkWell(
                          onTap: ()async{
                            FocusScope.of(context).unfocus();
                            await model.authenticate(widget.title);
                          },
                          child: Container(
                            height: 50,
                            margin: EdgeInsets.symmetric(horizontal: 60),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50),
                              color: Color.fromRGBO(49, 39, 79, 1),
                            ),
                            child: Center(
                              child: Text(widget.title, style: TextStyle(color: Colors.white),),
                            ),
                          ),
                        )),
                        SizedBox(height: 30,),
                        FadeAnimation(2, InkWell(
                            onTap: (){
                              Get.offAndToNamed('/${model.path}');
                            },
                            child: const Center(child: Text("Create Account", style: TextStyle(color: Color.fromRGBO(49, 39, 79, .6)),)))),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),)
    );
  }
}
class FadeAnimation extends StatelessWidget {
  final double delay;
  final Widget child;

  FadeAnimation(this.delay, this.child);

  @override
  Widget build(BuildContext context) {
    final tween = MultiTrackTween([
      Track("opacity").add(Duration(milliseconds: 500), Tween(begin: 0.0, end: 1.0)),
      Track("translateY").add(
          Duration(milliseconds: 500), Tween(begin: -30.0, end: 0.0),
          curve: Curves.easeOut)
    ]);

    return ControlledAnimation(
      delay: Duration(milliseconds: (500 * delay).round()),
      duration: tween.duration,
      tween: tween,
      child: child,
      builderWithChild: (context, child, animation) => Opacity(
        opacity: animation["opacity"],
        child: Transform.translate(
            offset: Offset(0, animation["translateY"]),
            child: child
        ),
      ),
    );
  }
}
