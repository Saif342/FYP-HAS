import 'package:flutter/material.dart';

class DoctorView extends StatefulWidget {
  const DoctorView({Key key}) : super(key: key);

  @override
  _DoctorViewState createState() => _DoctorViewState();
}

class _DoctorViewState extends State<DoctorView> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
