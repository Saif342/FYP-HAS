class Patient {
  String appointmentDate, clinicAddress, doctorName, patientName, patientAge;

  Patient({
     this.appointmentDate,
     this.clinicAddress,
     this.doctorName,
     this.patientName,
     this.patientAge,
  });
}
