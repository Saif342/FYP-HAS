class Doctor {
  int appointmentFee;
  String clinicAddress, clinicTime, name, qualifications, specialization, id;

  Doctor({
     this.id,
     this.appointmentFee,
     this.clinicAddress,
     this.clinicTime,
     this.name,
     this.qualifications,
     this.specialization,
  });
}
/*
  factory Doctor.fromJson(Map<String, dynamic> json) {
    return Doctor(
      appointmentFee: json['appointmentFee'],
      clinicAddress: json['clinicAddress'],
      clinicTime: json['clinicTime'],
      name: json['name'],
      qualifications: json['qualifications'],
      specialization: json['specialization'], 
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'appointmentFee': appointmentFee,
      'clinicAddress': clinicAddress,
      'clinicTime': clinicTime,
      'name': name,
      'qualifications': qualifications,
      'specialization': specialization,
    };
  }
}
*/
