import 'package:firebase_auth/firebase_auth.dart';

import '../../constants/constants.dart';
import 'package:doctor_appointment_admin/locator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AppointmentService {
  final FirebaseFirestore _firestore = locator<FirebaseFirestore>();
  User user=FirebaseAuth.instance.currentUser;
  DateTime currentDate = DateTime.now();
  DateTime get date =>
      DateTime(currentDate.year, currentDate.month, currentDate.day);

  Stream<QuerySnapshot<Map<String, dynamic>>> getAppointments(id) {
    return _firestore
        .collection(doctors_key)
        .doc(id)
        .collection(appointments_key)
        .where(date_key, isGreaterThanOrEqualTo: date)
        .orderBy(date_key)
        .limit(10)
        .snapshots();
  }
}
