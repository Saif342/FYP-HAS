import 'package:doctor_appointment_admin/enums/view_state.dart';
import 'package:doctor_appointment_admin/viewmodels/profile_viewmodel.dart';
import 'package:doctor_appointment_admin/ui/views/base_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({Key key}) : super(key: key);

  Widget _buildCoverImage() {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/images/doctor-background.jpg'),
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  Widget _buildProfileImage(ProfileViewmodel _model) {
    return Positioned(
      bottom: -106,
      child: Column(
        children: [
          CircleAvatar(
            radius: 60,
            backgroundColor: Colors.white,
            child: CircleAvatar(
              radius: 55,
              backgroundImage: AssetImage('assets/images/profile.png'),
            ),
          ),
          Text(
            _model.name,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Text(
            _model.specialization,
            style: TextStyle(fontSize: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(ProfileViewmodel _model) {
    return Stack(
      alignment: Alignment.center,
      clipBehavior: Clip.none,
      children: [
        _buildCoverImage(),
        _buildProfileImage(_model),
      ],
    );
  }

  Widget _buildInfo(IconData leading, String field, String value) {
    return Card(
      elevation: 4.0,
      child: ListTile(
        leading: Icon(
          leading,
          color: Colors.blue,
        ),
        title: Text('$field : $value'),
      ),
    );
  }

  Widget _buildProfileInfo(ProfileViewmodel _model) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ListView(
        children: [
          _buildInfo(Icons.timer, 'Timing', _model.timing),
          _buildInfo(Icons.money, 'Appointment fees', 'Rs ${_model.fees}/-'),
          _buildInfo(Icons.location_city, 'Address', _model.address),
        ],
      ),
    );
  }

  Widget _buildProfile(ProfileViewmodel _model) {
    return Column(
      children: [
        Expanded(
          flex: 1,
          child: _buildHeader(_model),
        ),
        Expanded(
          flex: 2,
          child: Container(
            margin: EdgeInsets.only(top: 120),
            child: _buildProfileInfo(_model),
          ),
        ),
        Align(
          alignment: Alignment.bottomRight,
          child: MaterialButton(
            onPressed: () => _model.signout(),
            shape: CircleBorder(),
            color: Color.fromRGBO(49, 39, 79, 1),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Icon(
                Icons.exit_to_app,
                color: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<ProfileViewmodel>(
      onModelReady: (model) {
        model.fetchProfile();
      },
      builder: (context, model, child) {
        if (model.state == ViewState.Busy) {
          return Center(child: CircularProgressIndicator());
        }
        return _buildProfile(model);
      },
    );
  }
}
