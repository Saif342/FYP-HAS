import 'package:doctor_appointment_admin/enums/view_state.dart';
import 'package:doctor_appointment_admin/ui/components/text_field/custom_textfield.dart';
import 'package:doctor_appointment_admin/ui/views/base_view.dart';
import 'package:doctor_appointment_admin/viewmodels/input_form_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'auth_view.dart';

class InputFormView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    void pickTime(
        InputFormViewModel model, DateTime initialtime, String command) async {
      var time = await showTimePicker(
        context: context,
        initialTime: TimeOfDay(
          hour: initialtime.hour,
          minute: initialtime.minute,
        ),
      );
      if (time != null) {
        model.setTime(time, command);
      }
    }

    return BaseView<InputFormViewModel>(
      onModelReady: (model) => model.onModelReady(),
      onModelDestroy: (model) => model.onModelDestroy(),
      builder: (context, model, child) {
        if (model.state == ViewState.Busy) {
          return Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }
        return Scaffold(
          appBar: AppBar(
            backgroundColor: Color.fromRGBO(49, 39, 79, 1),
            title: Center(
              child: Text('General Information'),
            ),
          ),
          body: Form(
            key: model.formKey,
            child: ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: CustomTextField(
                    controller: model.nameController,
                    label: 'Name',
                    prefix: Icon(Icons.person),
                    hint: 'Enter your Name',
                    validator: model.validateTextField,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: CustomTextField(
                    controller: model.qualificationController,
                    label: 'Qualification',
                    prefix: Icon(Icons.school),
                    hint: 'Enter your Qualification',
                    validator: model.validateTextField,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: CustomTextField(
                    controller: model.specializationController,
                    label: 'Specialization',
                    prefix: Icon(Icons.flag),
                    hint: 'Enter your specialization',
                    validator: model.validateTextField,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: CustomTextField(
                    controller: model.appointmentfeeController,
                    label: 'Appointment Fee',
                    prefix: Icon(Icons.paid),
                    validator: model.validateTextField,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Text(
                    'Timing: ',
                    style: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ),
                Row(
                  children: [
                    SizedBox(
                      width: w / 10,
                    ),
                    SizedBox(
                      width: w / 3,
                      child: Card(
                        child: ListTile(
                          onTap: () => pickTime(model, model.from, 'from'),
                          title: Text('From'),
                          subtitle: Text(DateFormat.jm().format(model.from)),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: w / 3,
                      child: Card(
                        child: ListTile(
                          onTap: () => pickTime(model, model.to, 'to'),
                          title: Text('To'),
                          subtitle: Text(DateFormat.jm().format(model.to)),
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: CustomTextField(
                    controller: model.addressController,
                    label: 'Address',
                    prefix: Icon(Icons.room),
                    hint: 'Enter the clinic address',
                    validator: model.validateTextField,
                    maxlines: 3,
                  ),
                ),
                SizedBox(height: 10.0,),
                FadeAnimation(1.9, InkWell(
                  onTap: ()async{
                    if (model.formKey.currentState.validate()) {
                      await model.setInfo();
                    }
                  },
                  child: Container(
                    height: 50,
                    margin: EdgeInsets.symmetric(horizontal: 60),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      color: Color.fromRGBO(49, 39, 79, 1),
                    ),
                    child: Center(
                      child: Text("Create", style: TextStyle(color: Colors.white),),
                    ),
                  ),
                )),

              ],
            ),
          ),
        );
      },
    );
  }
}
