class Patient {
  String name;
  String age;
  String address;

  Patient({
     this.name,
     this.age,
     this.address,
  });
}
