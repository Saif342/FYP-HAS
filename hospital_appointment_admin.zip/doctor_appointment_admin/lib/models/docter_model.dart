class Doctor {
  String name;
  String specialization;
  String timing;
  String address;
  String qualification;
  int fees;

  Doctor({
     this.name,
     this.specialization,
     this.timing,
     this.address,
     this.qualification,
     this.fees,
  });
}
