import 'package:doctor_appointment_admin/enums/view_state.dart';
import 'package:doctor_appointment_admin/locator.dart';
import 'package:doctor_appointment_admin/models/docter_model.dart';
import 'package:doctor_appointment_admin/services/profile_database_service.dart';
import 'package:doctor_appointment_admin/services/auth_service.dart';
import 'package:doctor_appointment_admin/services/localstorage_service.dart';
import 'package:doctor_appointment_admin/viewmodels/base_viewmodel.dart';
import 'package:get/get.dart';

class ProfileViewmodel extends BaseViewModel {
  final ProfileDatabaseService _profileService =
      locator<ProfileDatabaseService>();
  final FirebaseAuthService _firebaseAuthService =
      locator<FirebaseAuthService>();
  final LocalStorageService _localStorageService =
      locator<LocalStorageService>();

    Doctor _profile;

  Doctor get profile => _profile;

  set profile(Doctor profile) {
    _profile = profile;
    notifyListeners();
  }

  String get name => profile.name;
  String get qualification => profile.qualification;
  String get specialization => profile.specialization;
  String get address => profile.address;
  int get fees => profile.fees;
  String get timing => profile.timing;

  void fetchProfile() async {
    setState(ViewState.Busy);
    profile = await _profileService.profile;
    setState(ViewState.Idle);
  }

  void signout() async {
    await _firebaseAuthService.signOut();
    _localStorageService.isLoggedIn = false;
    Get.offAndToNamed('/login');
  }
}
