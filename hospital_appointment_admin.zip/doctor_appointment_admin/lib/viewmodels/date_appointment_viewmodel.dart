import 'package:doctor_appointment_admin/viewmodels/base_viewmodel.dart';

class DateAppointmentViewModel extends BaseViewModel {}
