import 'package:doctor_appointment_admin/locator.dart';
import 'package:doctor_appointment_admin/services/appointment_service.dart';
import 'package:doctor_appointment_admin/viewmodels/base_viewmodel.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AppointmentViewmodel extends BaseViewModel {
  final _appointmentService = locator<AppointmentService>();
var id;
  Stream<QuerySnapshot<Map<String, dynamic>>> get appointments =>
      _appointmentService.getAppointments(id);
}
