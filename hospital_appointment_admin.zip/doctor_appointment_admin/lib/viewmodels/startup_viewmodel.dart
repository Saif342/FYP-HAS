import 'package:doctor_appointment_admin/locator.dart';
import 'package:doctor_appointment_admin/services/localstorage_service.dart';
import 'package:doctor_appointment_admin/viewmodels/base_viewmodel.dart';
import 'package:get/get.dart';

class StartUpViewModel extends BaseViewModel {
  final LocalStorageService localStorageService =
      locator<LocalStorageService>();

  void onModelReady() async {
    await Future.delayed(
      const Duration(seconds: 2),
    );
    await Get.offAllNamed(
      localStorageService.isLoggedIn ? '/landing' : '/login',
    );
  }
}
