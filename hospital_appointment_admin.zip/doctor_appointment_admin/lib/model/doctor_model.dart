class Doctor {
  String name, address, qualification, specialization, timing;
  int fee;

  Doctor({
     this.name,
     this.address,
     this.qualification,
     this.specialization,
     this.timing,
     this.fee,
  });
}
