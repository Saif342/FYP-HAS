package com.example.doctor_appointment_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
